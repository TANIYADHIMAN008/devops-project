#include<stdio.h>
int  main() {
    printf("Hello, Taniya! This is my DevOps Project running inside Docker.\n");
return 0;
}
